//
//  MutableString.m
//  ch18
//
//  Created by zuxia on 15-9-11.
//  Copyright (c) 2015年 zuxia. All rights reserved.
//

#import "MutableString.h"

@implementation MutableString
+(void)displayOne{
//创建方法
    NSMutableString *string1=[[NSMutableString alloc] initWithCapacity:0];
    NSLog(@"%lu",[string1 retainCount]);
    [string1 release];
    NSMutableString *string2;
    //用静态方法创建的对象 系统会自动把对象加入自动释放次
      string2=[NSMutableString stringWithCapacity:0];
    //设置值
    [string2 setString:@"12班的要请我吃饭"];
    
    NSLog(@"string2 is %@",string2);
    //在指定位置插入字符串
    [string2 insertString:@"全体同学" atIndex:4];
    NSLog(@"%@",string2);
    
    //追加字符串
    [string2 appendFormat:@"%d%d%d",1,2,3];
    NSLog(@"%@",string2);
    
    //得到字符串在原字符串中的位置
    NSRange range=[string2 rangeOfString:@"123"];
    //替换指定位置
    [string2 replaceCharactersInRange:range withString:@"一半年"];
        NSLog(@"%@",string2);
    
    //删除指定位置
    [string2 deleteCharactersInRange:range];
     NSLog(@"%@",string2);
    
    [string2 writeToFile:@"/Users/zuxia/Desktop/iOS12.txt" atomically:NO encoding:NSUTF8StringEncoding error:nil];
    
    NSMutableString *string3=[NSMutableString stringWithContentsOfFile:@"/Users/zuxia/Desktop/iOS12.txt" encoding:NSUTF8StringEncoding error:nil];
    
    NSLog(@"---%@",string3);
    
    
 
}
@end
