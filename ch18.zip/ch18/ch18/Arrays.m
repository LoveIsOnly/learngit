//
//  Arrays.m
//  ch18
//
//  Created by zuxia on 15-9-11.
//  Copyright (c) 2015年 zuxia. All rights reserved.
//

#import "Arrays.h"

@implementation Arrays
+(void)display
{
    //创建方式
    //常量创建  直接赋值
    NSArray *array=@[@"Objective-C",@"S2wift",@"iOS"];
    NSLog(@"%@",array);
    
    //静态方法创建  nil表示结束
    NSArray *array1=[NSArray arrayWithObjects:@"apple",@"Android",@"winPhone",@"Android",nil];
    NSLog(@"%@",array1);
    //实例方法创建
    NSArray *array2=[[NSArray alloc] initWithObjects:@"iPhone4",@"iPhone6",@"iPhone7",@34, nil];
    [array2 release];
    NSLog(@"%@",array2);
    
    //得到数组长度
    
    NSUInteger length=[array1 count];
    length=array1.count;
    NSLog(@"%lu",length);
    //根据下标得到数组元素
    for(int i=0;i<length;i++)
    {
        id string1=[array1 objectAtIndex:i];
        if([string1 isKindOfClass:[NSArray class]])
        {
            NSArray *array=[array1 objectAtIndex:i];
            NSLog(@"%@",array);
        }
        else
        {
            NSString *tempstring=[array1 objectAtIndex:i];
            NSLog(@"---%@",tempstring);
        }
    }
    //得到数组最后一个元素
     NSArray *temparray=[array1 lastObject];
     NSLog(@"=====%@",temparray);
    //快速枚举 （增强for循环）
    for(id temp in array1)
    {
        NSLog(@"-%@",temp);
    }
    
   //不可变数组追加元素  生成一个新的数组
    NSArray *array3=[array1 arrayByAddingObject:@"NEW Object"];
    NSLog(@"arr3 is %@",array3);
    NSArray *arr4=[array1 arrayByAddingObjectsFromArray:array3];
    NSLog(@"%@",arr4);
    
    //将数组以指定字符串 合成字符串
    NSString *string2=[array1 componentsJoinedByString:@" and "];
    NSLog(@"string2 is %@",string2);
    
    NSArray *arr5=[string2 componentsSeparatedByString:@" and "];
    NSLog(@"arr5 is %@",arr5);
    
    //将数组排序 如果是NSString 按照 asicc值排序  如果是NSNumber 按照 、数值大小排序
    NSArray *arr6=[array1 sortedArrayUsingSelector:@selector(compare:)];
    
    NSLog(@"%@",arr6);
    NSLog(@"%d%d%d%d",'A','a','w','2');
    
    
    NSArray *array7=[NSArray arrayWithObjects:@121,@32,@24,@11, nil];
    
    NSArray *array8=[array7 sortedArrayUsingSelector:@selector(compare:)];
    NSLog(@"%@",array8);
    
    NSString *path=@"/Users/zuxia/Desktop/iOS.txt";
    
    //将数组写入指定路径
    if([arr6 writeToFile:path atomically:NO])
    {
        
        NSLog(@"文件写入成功");
    }
    else
    {
        NSLog(@"写入失败");
    }
    //将文件读取到数组中 文件内容必须有固定格式
    NSArray *array9=[NSArray arrayWithContentsOfFile:path];
    NSLog(@"%@",array9);
    
    NSString *string3=[NSString stringWithContentsOfFile:path encoding:NSUTF8StringEncoding error:nil];
    NSLog(@"%@",string3);
    
    
}
@end
