//
//  Stringwrite.h
//  ch18
//
//  Created by zuxia on 15-9-11.
//  Copyright (c) 2015年 zuxia. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Stringwrite : NSObject
+(void)displayOne;

@end
