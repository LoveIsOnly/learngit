//
//  MutableArrays.m
//  ch18
//
//  Created by zuxia on 15-9-11.
//  Copyright (c) 2015年 zuxia. All rights reserved.
//

#import "MutableArrays.h"

@implementation MutableArrays
+(void)display
{
    //可变数组创建方式
    
    //静态方法
    NSMutableArray *array1=[NSMutableArray arrayWithCapacity:0];
    
    //实例方法
    NSMutableArray *array2=[[NSMutableArray alloc] initWithCapacity:0];
    [array2 release];
    
    //添加元素
    
    [array1 addObject:@"iOS"];
    [array1 addObject:@"Android"];
    [array1 addObject:@"winPhone"];
//    [array1 addObject:@12];
//    [array1 addObject:@121];
   [array1 addObject:@"中国"];

    
    [array1 insertObject:@"java" atIndex:2];
    
    [array1 removeLastObject];
    [array1 removeObjectAtIndex:2];
//    [array1 removeObject:@"iOS" inRange:NSMakeRange(0, 1)];
    //排序
    [array1 sortUsingSelector:@selector(compare:)];
    //替换指定下标元素
    [array1 replaceObjectAtIndex:0 withObject:@"Java"];
    
    //移出指定元素 如果元素不存在 就没有反馈
    [array1 removeObject:@"winPhone"];
    
    ///追加数组
    [array1 addObjectsFromArray:array1];
    //交换指定下标元素
    [array1 exchangeObjectAtIndex:0 withObjectAtIndex:3];
    NSLog(@"%@",array1);
    
    
    
    
    
    
    
    
}
@end
