//
//  Stringwrite.m
//  ch18
//
//  Created by zuxia on 15-9-11.
//  Copyright (c) 2015年 zuxia. All rights reserved.
//

#import "Stringwrite.h"

@implementation Stringwrite
+(void)displayOne
{
    
    NSString *content=@"那一年冬天下半夜两点多！很冷！";
    NSString *path=@"/Users/zuxia/Desktop/iOS12.txt";
    //将字符串写入指定路径   写文件时 如果文件存在就覆盖 否则创建
    if([content writeToFile:path atomically:NO encoding:NSUTF8StringEncoding error:nil])
    {
        NSLog(@"写入成功");
    }
    //根据指定路径读取文件数据
    NSString *content1=[NSString stringWithContentsOfFile:path encoding:NSUTF8StringEncoding error:nil];
    NSLog(@"%@",content1);
    
}
@end
