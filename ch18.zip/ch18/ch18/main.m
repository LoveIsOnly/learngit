//
//  main.m
//  ch18
//
//  Created by zuxia on 15-9-11.
//  Copyright (c) 2015年 zuxia. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Stringwrite.h"
#import "MutableString.h"
#import "Arrays.h"
#import "MutableArrays.h"

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
//        [Stringwrite displayOne];
//        [MutableString displayOne];
//        [Arrays display];
        [MutableArrays display];
    
    }
    return 0;
}

