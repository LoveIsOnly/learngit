

   内存管理
   只要是用静态方法创建的对象都不需要手动管理
   
   
   将字符串写入指定路径   写文件时 如果文件存在就覆盖 否则创建
   [content writeToFile:path atomically:NO encoding:NSUTF8StringEncoding error:nil]
   
   读取文件
   [string2 writeToFile:@"/Users/zuxia/Desktop/iOS12.txt" atomically:NO encoding:NSUTF8StringEncoding error:nil];
   
   

   
  可变类型（NSMutalbe..）调用 添加元素、排序方法的时候 方法是没有返回值的 直接自己接收
  
  不可变 类型       调用 添加元素、排序方法的时候 方法是有返回值的 必须定义一个对象来接收  原类型数据不变  
  
NSMutalbeString

 创建方法
  1、实力方法（alloc）需要管理内存
  2、静态方法 （类名调用的） 系统会自动管理
  
  设置值方法
  setString:
  
 在指定位置插入字符串
 insertString:@"全体同学" atIndex:4
 追加
 appendFormat:
 appendString:
 得到字符串在原字符串中的位置
（NSRange） rangeOfString:
 替换指定位置
 replaceCharactersInRange: withString:
 删除指定位置
 deleteCharactersInRange:
 
 NSArray
  1、实力方法（alloc）需要管理内存
  2、静态方法 （类名调用的） 系统会自动管理
  3、常量
 
   方法
   得到数组长度
   （NSUinteger）count
   得到数组最后一个元素
     （id） lastObject
       
   不可变数组追加元素  生成一个新的数组
   (NSArray *)  arrayByAddingObject:
   (NSArray *) arrayByAddingObjectsFromArray:
    
    将数组以指定字符串 合成字符串
    （NSString *）componentsJoinedByString:
  
     将数组排序 如果是NSString 按照 asicc值排序  如果是NSNumber按照 、数值大小排序   NSNumber类型数组只能进行单独排序  混排会报错
   （ NSArray *a） sortedArrayUsingSelector:@selector(compare:)
   
      将数组写入文件
     （BOOL） writeToFile: atomically:
     
      将文件读取到数组中 文件内容必须有固定格式
     （ NSArray *） arrayWithContentsOfFile:
     
     
     NSMutalbeArray
     
   1、实力方法（alloc）需要管理内存
  2、静态方法 （类名调用的） 系统会自动管理


方法
     
    添加元素
- (void)addObject:(id)anObject;
   在指定位置插入元素
- (void)insertObject:(id)anObject atIndex:(NSUInteger)index;
   删除最后一个元素
- (void)removeLastObject;
  根据下标删除元素
- (void)removeObjectAtIndex:(NSUInteger)index;
  删除指定元素
- (void)removeObject:(id)anObject;
 交换指定下标元素
- (void)exchangeObjectAtIndex:(NSUInteger)idx1 withObjectAtIndex:(NSUInteger)idx2;

  删除全部元素
  - (void)removeAllObjects;
  
  （ NSArray *a） sortedArrayUsingSelector:@selector(compare:)
   
    将数组写入文件
    （BOOL） writeToFile: atomically:
     
    将文件读取到数组中 文件内容必须有固定格式
    （ NSArray *） arrayWithContentsOfFile:

     
  